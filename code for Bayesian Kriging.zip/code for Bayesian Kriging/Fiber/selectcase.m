clear all
load fiberdata 
load fibertest
%%
global X  Y  n  d
x=fiberdata(:,1:4);y=fiberdata(:,5);Yt=y;
xte=fibertest(:,1:4);yte=fibertest(:,5);
[n,d]=size(x);
X=bian(x);% normalize the input scale 
mS = mean(y);
Y = (y - repmat(mS,n,1));
lb=0.01*ones(1,d);ub=4*ones(1,d);theta0=0.1*ones(1,d);
c=10;
k=2*d^2;
Bt=100000;%number of iteration
burnin=10000;%burn-in
thin=5;%thinning parameter
zq=norminv(1-0.05/(2*20),0,1);
fr=10;
p=[0.25 0.25/2 0.5/4 0]';
options = optimoptions('patternsearch','MaxIterations',10^6,'MeshTolerance',10^-10,'TolFun',10^-8,'TolX',10^-8,'MaxFunEvals',10^8);
theta=patternsearch(@myln,10*ones(1,d),[],[],[],[],lb,ub,options);
delta=0*ones(1,k); 
R=corrgausR(theta);
iR=ivd(R);
F=myff(X);
F=(eye(n)-ones(n,1)*ones(1,n)/n)*F;
tao=(1./(3*(max(F)-min(F))));
interm=interxi(d);
inter=interm(3,:);
P=[p(1)*ones(1,2*d) p(4)*ones(1,k-2*d)];
setting.n=n;
    setting.d=d;
    setting.zq=zq;
    setting.lb=lb;
    setting.ub=ub;
    setting.fr=fr;
    setting.k=k;
    setting.x=x;
    setting.X=X;
    setting.Yt=Yt;
    setting.Y=Y;
    setting.c=c;
    setting.Bt=Bt;
    setting.burnin= burnin;
    setting.thin=thin;
    setting.p=p;
    setting.iR=iR;
    setting.F=F;
    setting.tao=tao;
    setting.interm=interm;
    setting.inter=inter;
    setting.P=P;
    setting.delta=delta;
    [aanst,afreqt,dzt,uzt,sigma2zt]=BK(setting);
    [aanss,afreqs,dzs,uzs,sigma2zs]=SSBK(setting);  
%% Statistical test for Kriging models 
[n,d]=size(x);k=2*d^2;
B=100;
% OK
dmodel0=dacefit(x,y,@regpoly0,@corrgauss,theta0,lb,ub);
ypte=predictor(xte,dmodel0);
RMSE0=sqrt(mean((ypte-yte).^2));
theta=dmodel0.theta;
sigma2=dmodel0.sigma2;
C=dmodel0.C;
R=full(C*(C)');
%bootstrap sampling
mu=ones(n,1);
SIGMA=sigma2*R;
Ya=(mvnrnd(mu,SIGMA,B))';
ey=zeros(n,B); 
for i=1:n
    xc=x(i,:);
    yc=y(i,:);
    xx=x;yy=y;
    xx(i,:)=[];yy(i,:)=[];
    dmodel=dacefit(xx,yy,@regpoly0,@corrgauss,theta,lb,ub);
    [yt0(i),~,mse0(i)]=predictor(xc,dmodel);
    z0(i)=abs(yt0(i)-yc)/sqrt(mse0(i));
end
CVRMSE0=sqrt(mean((yt0'-y).^2));
mser0=sqrt(mse0);
mz0=max(z0);
for b=1:B        
    Yb=Ya(:,b);
    for i=1:n
        xx=x;yy=Yb;
        xc=x(i,:);yc=Yb(i,:);
        xx(i,:)=[];yy(i)=[];
        dmodel=dacefit(xx,yy,@regpoly0,@corrgauss,theta,lb,ub);
        yt(i,b)=predictor(xc,dmodel);
    end
    ey(:,b)=(Yb-yt(:,b)).^2;
end
mseb0=mean(ey,2);mserb0=sqrt(mseb0);
zb0=abs(yt0'-y)./mserb0;
mzb0=max(zb0);

% UK
dmodel0=dacefit(x,y,@regpoly1,@corrgauss,theta0,lb,ub);
ypte1=predictor(xte,dmodel0);
RMSE1=sqrt(mean((ypte1-yte).^2));
theta=dmodel0.theta;
sigma2=dmodel0.sigma2;
C=dmodel0.C;
R=full(C*(C)');
%bootstrap sampling
mu=ones(n,1);
SIGMA=sigma2*R;
Ya=(mvnrnd(mu,SIGMA,B))';
ey=zeros(n,B);
for i=1:n
    xc=x(i,:);
    yc=y(i,:);
    xx=x;yy=y;
    xx(i,:)=[];yy(i,:)=[];
    dmodel=dacefit(xx,yy,@regpoly1,@corrgauss,theta,lb,ub);
    [yt1(i),~,mse1(i)]=predictor(xc,dmodel);
    z1(i)=abs(yt1(i)-yc)/sqrt(mse1(i));
end
CVRMSE1=sqrt(mean((yt1'-y).^2));
mser1=sqrt(mse1);
mz1=max(z1);
for b=1:B        
    Yb=Ya(:,b);
    for i=1:n
        xx=x;yy=Yb;
        xc=x(i,:);yc=Yb(i,:);
        xx(i,:)=[];yy(i)=[];
        dmodel=dacefit(xx,yy,@regpoly1,@corrgauss,theta,lb,ub);
        yt(i,b)=predictor(xc,dmodel);
    end
    ey(:,b)=(Yb-yt(:,b)).^2;
end
mseb1=mean(ey,2);mserb1=sqrt(mseb1);
zb1=abs(yt1'-y)./mserb1;mzb1=max(zb1);

% BK
for hs=1:fr
    sf=find(aanst(hs,:)~=0);
    sel=aanst(hs,sf);
    index=zeros(1,k);index(sel)=1;
    dmodel0=dacefit(x,y,@(x)myregpoly2f(x,index),@corrgauss,theta0,lb,ub);
    ypte2=predictor(xte,dmodel0);
    RMSE2(hs)=sqrt(mean((ypte2-yte).^2));
    theta=dmodel0.theta;
    sigma2=dmodel0.sigma2;
    C=dmodel0.C;
    R=full(C*(C)');
    %bootstrap sampling
    mu=ones(n,1);
    SIGMA=sigma2*R;
    Ya=(mvnrnd(mu,SIGMA,B))';
    ey=zeros(n,B);%
    for i=1:n
        xc=x(i,:);
        yc=y(i,:);
        xx=x;yy=y;
        xx(i,:)=[];yy(i,:)=[];
        dmodel=dacefit(xx,yy,@(xx)myregpoly2f(xx,index),@corrgauss,theta,lb,ub);
        [yt2(i),~,mse2(i)]=predictor(xc,dmodel);
        z2(i)=abs(yt2(i)-yc)/sqrt(mse2(i));
    end
    mser2=sqrt(mse2);
    zc2(hs,:)=z2;
    mz2(hs)=max(z2);
    CVRMSE2(hs)=sqrt(mean((yt2'-y).^2));
    for b=1:B        
        Yb=Ya(:,b);
        for i=1:n
            xx=x;yy=Yb;
            xc=x(i,:);yc=Yb(i,:);
            xx(i,:)=[];yy(i)=[];
            dmodel=dacefit(xx,yy,@(xx)myregpoly2f(xx,index),@corrgauss,theta,lb,ub);
            yt(i,b)=predictor(xc,dmodel);
        end
        ey(:,b)=(Yb-yt(:,b)).^2;
    end
    mseb2=mean(ey,2);mserb2=sqrt(mseb2);
    zb2(hs,:)=abs(yt2'-y)./mserb2;
    mzb2(hs)=max(zb2(hs,:));
end
plot(mser2,'-b')
hold on 
plot(mserb2,'-r')
hold off