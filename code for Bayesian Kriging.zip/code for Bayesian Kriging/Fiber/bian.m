function y=bian(x)
[n,~]=size(x);
a=min(x);b=max(x);
c=(b-a)/2;
a=repmat(a,n,1);
c=repmat(c,n,1);
y=(x+c-a)./c;
end 