function [aans,afreq,dz,uz,sigma2z]=BK(setting)
n = setting.n;
d = setting.d;
zq = setting.zq;
lb = setting.lb;
ub = setting.ub;
fr = setting.fr;
k = setting.k;
x = setting.x;
X = setting.X;
Yt = setting.Yt;
Y = setting.Y;
c = setting.c;
Bt = setting.Bt;
burnin = setting.burnin;
thin = setting.thin;
p = setting.p;
iR = setting.iR;
F = setting.F;
tao = setting.tao;
interm = setting.interm;
inter=setting.inter;
P = setting.P;
delta=setting.delta;
for t=1:Bt
    %% update ��2 
    iD=diag(1./(((c.^delta).*tao).^2));
    B=F'*iR*Y;
    A=F'*iR*F+iD;
    iA=ivd(A);
    g1=n/2;g2=1/2*(Y'*iR*Y-B'*iA*B);
    g=gamrnd(g1,1/g2);
    sigma2=1/g;
    %% update u  
    mu=iA*B;
    SIGMA=sigma2*iA;
%     SIGMA=zeros(k,k);
    u=(mvnrnd(mu',SIGMA,1))';
    %% update �� 
    mm=delta;%
    rd=randperm(k);
    for j=1:k
        
        mm0=mm;mm0(rd(j))=0;
        mm1=mm;mm1(rd(j))=1;
        
        if ismember(rd(j),inter)  
            I=find(inter==rd(j)); 
            He=interm(:,I);  
            
            if mm(He([1 2]))==[0 0]'
                P(rd(j))=p(4);
            elseif (mm(He([1 2]))==[1;0])|(mm(He([1 2]))==[0;1])
                P(rd(j))=p(3);
            else
                P(rd(j))=p(2);
            end
        end
        iDdelta0=diag(1./(((c.^mm0).*tao).^2)); iDdelta1=diag(1./(((c.^mm1).*tao).^2));
        yRy=Y'*iR*Y;FRF=F'*iR*F;
        a=det(iDdelta1)^(1/2)*P(rd(j))*(yRy-B'/(FRF+iDdelta1)*B)^(-n/2);
        b=det(iDdelta0)^(1/2)*(1-P(rd(j)))*(yRy-B'/(FRF+iDdelta0)*B)^(-n/2);
        prdj2=a/(a+b);
        mm(rd(j))=binornd(1,prdj2);
    end
    delta=mm; 
    iD=diag(1./(((c.^delta).*tao).^2));
    dz(t,:)=delta;
    uz(t,:)=u;
    sigma2z(t)=sigma2;
end
aa=round((Bt-burnin)/thin);
for i=1:aa
    gib(i,:)=dz(burnin+thin*i,:);
end
[C,~,IC]=unique(gib,'rows');
ind=histc(IC,1:size(C,1));
[bb,inx]=sort(ind,'descend');
fr=10;
aans=zeros(fr,10);
for i=1:fr
    cc=find(C(inx(i),:)==1);
    aans(i,1:size(cc,2))=cc;
end
aans
afreq=bb(1:fr)/size(gib,1)
