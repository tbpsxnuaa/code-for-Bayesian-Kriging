clear all
%%
global X  Y  n
n=60;d=8;
lb=0.01*ones(1,d);ub=4*ones(1,d);theta0=0.1*ones(1,d);fr=10;nc=1000;k=2*d^2;
lob=zeros(1,d)+0.001;upb=ones(1,d);
iter=1;
zq=norminv(1-0.01/2,0,1);
dis=zeros(iter,6);
for it=1:iter
    xfopt=[];
    m=[];mb=[];
    x=lhsdesign(n,d,'smooth','off','criterion','maximin');X=x;
    Yt=bore(x);
    mS = mean(Yt);
    Y =Yt-repmat(mS,n,1);
    c=10;
    k=2*d^2;%number of candidate variables in mean function
    Bt=100000;%number of iteration in MCMC
    burnin=10000;%burn-in
    thin=5;%thinning parameter
    p=[0.25 0.25/2 0.25/4 0]'; % sparse prior
    options = optimoptions('patternsearch','MaxIterations',10^6,'MeshTolerance',10^-10,'TolFun',10^-8,'TolX',10^-8,'MaxFunEvals',10^8);
    theta=patternsearch(@myln,10*ones(1,d),[],[],[],[],lb,ub,options); % obtain the initial value for theta
    delta=0*ones(1,k); 
    R=corrgausR(theta);
    iR=ivd(R);
    F=myff(x);
    F=(eye(n)-ones(n,1)*ones(1,n)/n)*F;
    tao=(1./(3*(max(F)-min(F))));
    interm=interxi(d);
    inter=interm(3,:);
    P=[p(1)*ones(1,2*d) p(4)*ones(1,k-2*d)];
    setting.n=n;
    setting.d=d;
    setting.zq=zq;
    setting.lb=lb;
    setting.ub=ub;
    setting.fr=fr;
    setting.k=k;
    setting.x=x;
    setting.X=X;
    setting.Yt=Yt;
    setting.Y=Y;
    setting.c=c;
    setting.Bt=Bt;
    setting.burnin= burnin;
    setting.thin=thin;
    setting.p=p;
    setting.iR=iR;
    setting.F=F;
    setting.tao=tao;
    setting.interm=interm;
    setting.inter=inter;
    setting.P=P;
    setting.delta=delta;
    [aanst,afreqt]=BK(setting); %output the models with high posterior probabilites and their frequencies 
    [aanss,afreqs]=SSBK(setting); 
    %% Statistical test for Cross-Validation of BK models
    Y=Yt;
    B=1000;
    nt=1000;    xte=lhsdesign(nt,d,'smooth','off','criterion','maximin');yte=bore(xte);
    for hs=1:10
        sf=find(aanst(hs,:)~=0);
        sel=aanst(hs,sf);
        index=zeros(1,k);index(sel)=1;
        dmodel0=dacefit(X,Y,@(X)myregpoly2(X,index),@corrgauss,theta0,lb,ub);
        ypte=predictor(xte,dmodel0);
        RMSE2(hs)=sqrt(mean((ypte-yte).^2));
        theta=dmodel0.theta;
        sigma2=dmodel0.sigma2;
        C=dmodel0.C;
        R=full(C*(C)');
        %bootstrap sampling
        mu=ones(n,1);
        SIGMA=sigma2*R;
        Ya=(mvnrnd(mu,SIGMA,B))';
        ey=zeros(n,B);
        for i=1:n
            xc=X(i,:);
            yc=Y(i,:);
            x=X;y=Y;
            x(i,:)=[];y(i,:)=[];
            dmodel=dacefit(x,y,@(X)myregpoly2(X,index),@corrgauss,theta,lb,ub);
            [yt2(i),~,mse2(i)]=predictor(xc,dmodel);
            z2(i)=abs(yt2(i)-yc)/sqrt(mse2(i));
        end
        mser2=sqrt(mse2);
        mz2(hs)=max(z2);
        CVRMSE2(hs)=sqrt(mean((yt2'-Yt).^2));
        for b=1:B
            Yb=Ya(:,b);
            for i=1:n
                x=X;y=Yb;
                xc=X(i,:);yc=Yb(i,:);
                x(i,:)=[];y(i)=[];
                dmodel=dacefit(x,y,@(X)myregpoly2(X,index),@corrgauss,theta,lb,ub);
                yt(i,b)=predictor(xc,dmodel);
            end
            ey(:,b)=(Yb-yt(:,b)).^2;
        end
        mseb2=mean(ey,2);mserb2=sqrt(mseb2);
        zb2=abs(yt2'-Y)./mserb2;
        mzb2(hs)=max(zb2);
    end
    mzcons(it,:)= mz2;
    mzbcons(it,:)=mzb2;
%     rmsecons(it,:)=CVRMSE2;
    rmsecons(it,:)=RMSE2;
    aanscons(:,:,it)=aanst;
    aanss(it,:)=aanss(1,:);
    afreqcons(it,:)=afreqt;
    xcons(:,:,it)=X;
    it
end
