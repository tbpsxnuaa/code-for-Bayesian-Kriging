function y=interxi(d)
t=1;
%һ�׽�����ı�ʾ
for i=1:(d-1)
    a(t:t+d-i-1)=i;
    b(t:t+d-i-1)=[i+1:d];
    c(t:t+d-i-1)=[2*d+t:2*d+t+d-i-1];
    t=t+d-i;
end
%һ��yu���׽�����ı�ʾ
for i=1:(d-1)
    a(t:t+d-i-1)=i+d;
    b(t:t+d-i-1)=[i+1:d];
    c(t:t+d-i-1)=[2*d+t:2*d+t+d-i-1];
    t=t+d-i;
end
%����yuһ�׽�����ı�ʾ
for i=1:(d-1)
    a(t:t+d-i-1)=i;
    b(t:t+d-i-1)=[i+1+d:2*d];
    c(t:t+d-i-1)=[2*d+t:2*d+t+d-i-1];
    t=t+d-i;
end
for i=1:(d-1)
    a(t:t+d-i-1)=i+d;
    b(t:t+d-i-1)=[i+1+d:2*d];
    c(t:t+d-i-1)=[2*d+t:2*d+t+d-i-1];
    t=t+d-i;
end
y=[a;b;c];
end