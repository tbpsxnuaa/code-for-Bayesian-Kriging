load boreresult  
% parameter design
    T=7.8202;
    m=find(mz2<zq);mb=find(mzb2<zq);
    [~,locb]=min(RMSE2(mb));[~,loc]=min(RMSE2(m));
%     [~,locb]=min(CVRMSE2(mb));[~,loc]=min(CVRMSE2(m));
    x=X;y=Yt;
    ans1=[zeros(1,10);1:1:d zeros(1,10-d);aanss(1,:);aanst];
    bp=mb(locb)+2;cp=m(loc)+2;
    % find the opt for OK\UK\BK(10) model
    for hs=1:size(ans1,1)
        sf=find(ans1(hs,:)~=0);
        sel=ans1(hs,sf);
        index=zeros(1,k);index(sel)=1;
        dmodel=dacefit(x,y,@(x)myregpoly2(x,index),@corrgauss,theta0,lb,ub);
        sdmodela(hs)=dmodel;
        for t=1:5
            xoptt(t,:)=ga(@(xb)maxp(xb,dmodel,afreqt),d,[],[],[],[],lob,upb);
            pint(t)=maxp(xoptt(t,:),dmodel,afreqt);
        end
        [~,id]=min(pint);
        xopt(hs,:)=xoptt(id,:);
    end
    %  find the opt for BMAK
    sdmodel2=sdmodela(4:end);
    for t=1:5
        xoptt(t,:)=ga(@(xb)maxp(xb,sdmodel2,afreqt),d,[],[],[],[],lob,upb);
        pint(t)=maxp(xoptt(t,:),sdmodel2,afreqt);
    end
    [~,id]=min(pint);
    xfopt(1:3,:)=xopt(1:3,:);%OK UK SSBK
    xfopt(4,:)=xoptt(id,:);%BMAK
    if isempty(cp)
    else
        xfopt(5,:)=xopt(cp,:);%TBK-CV
    end
    if isempty(bp)
    else
        xfopt(6,:)=xopt(bp,:);%TBK-BV
    end
    ymu=bore(xfopt);% true value for each method
    len=length(ymu);
    dis(1:len)=abs(T-ymu);    