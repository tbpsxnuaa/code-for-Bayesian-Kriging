function R=corrcubiR(x)%�����x=(��1,��2,��������d,�ˣ��ң�
global X n d
for i=1:n
      for j=1:n
        b=1;
        h=abs(X(i,:)-X(j,:));
        for t=1:d
            p(t)=abs(h(t)/x(t));
            c1=((0<=p(t)) & (p(t)<0.5));
            c2=((0.5<=p(t)) & (p(t)<=1));
            a=c1*(1-6*p(t)^2+6*p(t)^3)+c2*(2*(1-p(t))^3);
            b=b*a;    
        end
        R(i,j)=b;
    end
end
R=R+eye(n)*x(d+1);

end