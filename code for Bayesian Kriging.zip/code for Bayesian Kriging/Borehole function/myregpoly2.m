function  [f, df] = myregpoly2(S,index)
%REGPOLY1  First order polynomial regression function
%
% Call:    f = regpoly1(S)
%          [f, df] = regpoly1(S)
%
% S : m*n matrix with design sites
% f = [1  s]
% df : Jacobian at the first point (first row in S) 

% hbn@imm.dtu.dk  
% Last update April 12, 2002
[m,n] = size(S);k=2*n^2;
ff=myff(S);
sele=find(index==1);
f = [ones(m,1) ff(:,sele)];

% if  nargout > 1
%   df = [zeros(n,1) zeros(n,k)];%���ڲ��漰���ݶ� �ʿ��Բ���עdf��ô��д
  
if  nargout > 1
  df = [zeros(n,1)  eye(n)  zeros(n,2*n^2-n-1)];
  df(1:n,n+2:2*n+1)=diag(2*S(1,1:n));
  j = 2*n+1;   q = n; 
  for  k = 1 : n
    df(k,j+(1:q-1)) = S(1,k+1:n);
    for i = 1 : n-k,  df(k+i,j+i) = S(1,k); end
    q = q-1;j = j+q;   
  end
  
  j=2*n+1+n*(n-1)/2;q=n;
  for  k = 1 : n
    df(k,j+(1:q-1)) = 2*S(1,k)*S(1,k+1:n);
    for i = 1 : n-k,  df(k+i,j+i) = S(1,k)^2; end
    q = q-1;j = j+q;   
  end
  
  j=2*n+1+n*(n-1);q=n;
  for  k = 1 : n
    df(k,j+(1:q-1)) = S(1,k+1:n).^2;
    for i = 1 : n-k,  df(k+i,j+i) = 2*S(1,k)*S(1,k+i); end
    q = q-1;j = j+q;   
  end
  
  j=2*n+1+3/2*n*(n-1);q=n;
  for  k = 1 : n
    df(k,j+(1:q-1)) = 2*S(1,k)*S(1,k+1:n).^2;
    for i = 1 : n-k,  df(k+i,j+i) = 2*S(1,k)^2*S(1,k+i); end
    q = q-1;j = j+q;   
  end
  
  df = [zeros(n,1) df(:,sele+1)];%��Ϊ��һ���ǳ�����  ����������Ҫ��Ӧ������һ
  
end 
  
end