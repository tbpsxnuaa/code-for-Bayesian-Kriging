function yx=maxp(x,model)
global af
sd=size(model,2);
if sd==1
    [mu,~,sigma2,~]=predictor(x,model);
else
    for hs=1:sd
        [imu(hs),~,isigma2(hs),~]=predictor(x,model(hs));
    end
    mu=imu*af;
    sigma2=(isigma2+imu.^2)*af-mu^2;
end
% yx=sigma2+(mu-T)^2;
yx=sigma2+mu^2;
% sigma=sqrt(sigma2);yx=normcdf(l,mu,sigma)-normcdf(u,mu,sigma);% �Ǹ�ֵΪ�������С������  
end
