clear all
load result27
for a=1:100
% a=10;
afreq=afreqcons(a,:);
X=xcons(:,:,a);
mz=mzcons(a,3:12);mzb=mzbcons(a,3:12);ans1=aanscons(:,:,a);
global  af
x=X;
af=afreq;[n,d]=size(x);k=2*d^2;y=bore(x);y=y-repmat(mean(y),n,1);
zq=norminv(1-0.05/(2*n),0,1);
wf=find(mz<zq);
wb=find(mzb<zq);
lb=0.01*ones(1,d);ub=10*ones(1,d);theta0=1*ones(1,d);
%%
num=[1,5,10];
for epoach=1:3
nc=num(epoach)*1000;y0=zeros(nc,1);y1=zeros(nc,1); %different training size
xc=lhsdesign(nc,d,'criterion','correlation','iterations',200);
yc=bore(xc);
lob=zeros(1,d)+0.001;upb=ones(1,d);
dmode0=dacefit(x,y,@regpoly0,@corrgauss,theta0,lb,ub);
for i=1:nc
    [y0(i)]=predictor(xc(i,:),dmode0);
end
rmse0=sqrt(mean((yc-y0).^2));

dmodel=dacefit(x,y,@regpoly1,@corrgauss,theta0,lb,ub);
for i=1:nc
    [y1(i)]=predictor(xc(i,:),dmodel);
end
rmse1=sqrt(mean((yc-y1).^2));

y2y=zeros(nc,10);
for hs=1:10
    sf=find(ans1(hs,:)~=0);
    sel=ans1(hs,sf);
    index=zeros(1,k);index(sel)=1;
    dmodel=dacefit(x,y,@(X)myregpoly2(X,index),@corrgauss,theta0,lb,ub);
    for i=1:nc
        [y2y(i,hs)]=predictor(xc(i,:),dmodel);
    end
    rmsea2(hs)=sqrt(mean((yc-y2y(:,hs)).^2));
end
[~,mloc]=min(rmsea2(wf));
[~,mlocb]=min(rmsea2(wb));
rmse2=rmsea2(1);
if isempty(mloc)
    rmse4=rmse2;
else
    rmse4=rmsea2(wf(mloc));
    loc(epoach)=wf(mloc);
end

if isempty(mlocb)
    rmse5=rmse2;
else
    rmse5=rmsea2(wb(mlocb));
    locb(epoach)=wb(mlocb);
end
afe=af./sum(af);
y3=y2y*afe';rmse3=sqrt(mean((yc-y3).^2));

sumrmse(a,:,epoach)=[rmse0,rmse1,rmse2,rmse3,rmse4,rmse5];
end
a
end
data_matrix=sumrmse(:,3:6); % BMAK TBK-CV TBK-BV
[n, m] = size(data_matrix);
% set group
groups = repmat(1:m, n, 1);
groups = groups(:);
data = data_matrix(:);
% ANOVA
[p, tbl, stats] = anova1(data, groups);
disp(tbl);
if p < 0.05
    % multicompose
    results = multcompare(stats, 'CType', 'hsd');   
    disp(results);
else
end